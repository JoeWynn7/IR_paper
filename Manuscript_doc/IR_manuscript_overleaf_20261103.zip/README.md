# Indirect reciprocity with inertial reputation updating: LaTeX source

Main file: `Manuscript_full_20261103.tex`. It holds the main text, Methods, Extended Data and Supplementary Information.

## Compile

- **Overleaf:** upload this ZIP as a new project and compile with pdfLaTeX. Overleaf's latexmk runs BibTeX for both the main and the Supplementary reference lists.
- **Locally:** run `latexmk -pdf Manuscript_full_20261103.tex`. The manual sequence is pdflatex, then `bibtex Manuscript_full_20261103`, then `bibtex SI`, then pdflatex twice.

## Files

| File | Purpose |
|---|---|
| `references.bib` | Bibliography. Entries prefixed `SI-` are copies used by the separate SI reference list (multibib). |
| `wlscirep.cls`, `naturemag-doi.bst`, `jabbrv*` | Class, bibliography style and journal-abbreviation files required by the class. |
| `figures/` | Main (`Fig*.pdf`) and Extended Data (`ED_Fig*.pdf`) figures. |

Draft notes print in dark red. Set `\draftnotesfalse` in the preamble to hide them.
