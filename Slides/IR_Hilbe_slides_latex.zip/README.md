# Indirect reciprocity with inertial reputation updating: slides

Beamer source of the slides for the discussion with Christian Hilbe.

- **Main file:** `IR_Hilbe_slides.tex` (metropolis theme, 16:9). It compiles with pdfLaTeX and BibTeX.
  - **Overleaf:** upload this ZIP and compile with pdfLaTeX.
  - **Locally:** run `latexmk -pdf IR_Hilbe_slides.tex`.
- **Bibliography:** `slides_refs.bib` (natbib, `plainnat` style).
- **Figures:** `figures/` holds the main-text figures, the Extended Data figures, the verified-data rendering of Fig. 4 and the reputation-map plot.

Metropolis prefers XeLaTeX with Fira fonts. With pdfLaTeX it falls back to the default sans-serif font and prints a harmless warning.
